<?php 
    include "admin/includes/connect.php";


    include "header.php";
    include "hero-section.php";
    include "about-section.php";
    include "skill-section.php";
    include "service-section.php";
    include "portfolio-section.php";
    include "reviews-section.php";
    include "testimonial-section.php";
    include "footer.php";

?>

